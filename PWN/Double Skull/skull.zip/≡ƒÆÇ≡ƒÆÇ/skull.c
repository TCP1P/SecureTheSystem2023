#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/init.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("hyffs");

#define DEVICE_NAME "skull"

static int Major;

struct request_t {
        void *dst;
        void *src;
};

static int chrdev_open(struct inode *inode, struct file *filp){
        return 0;
}

static int chrdev_close(struct inode *inode, struct file *filp){
        return 0;
}

long gyattt_ioctl(struct file *filp, unsigned int cmd, unsigned long args){
        struct request_t req;

        if(copy_from_user(&req, (struct request_t*)args, sizeof(struct request_t)))
                return -EINVAL;
        
        if(cmd == 0x6969)
                if(_copy_to_user(req.dst, req.src, 8))
                        return -EINVAL;
		
        return 0;       
}

ssize_t buffow_me(struct file *filp, const char __user *ubuff, size_t count, loff_t *offset){
	char data[0x100];

	if(_copy_from_user(&data, ubuff, count))
                return -EFAULT;

	return 0;
}

static struct file_operations fops = {
        .owner = THIS_MODULE,
        .open = chrdev_open,
        .release = chrdev_close,
        .unlocked_ioctl = gyattt_ioctl,
	.write = buffow_me,
};

static int __init this_is_init(void){
        if((Major = register_chrdev(0, DEVICE_NAME, &fops)) < 0)
                return Major;
                
        return 0;
}

static void __exit this_is_exit(void){
        unregister_chrdev(Major, DEVICE_NAME);
}

module_init(this_is_init);
module_exit(this_is_exit);
